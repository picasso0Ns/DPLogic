import os
import torch
import numpy as np
import random
import json

def create_dirs():
    """
    Create necessary directories for the project.
    """
    dirs = ['models', 'data_utils', 'optimization', 'checkpoints', 'results']
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    
    # Create __init__.py files for proper imports
    for d in dirs:
        init_file = os.path.join(d, '__init__.py')
        if not os.path.exists(init_file):
            with open(init_file, 'w') as f:
                pass

def save_model(model, path):
    """
    Save model weights to a file.
    
    Args:
        model: PyTorch model
        path: Path to save the model
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(model.state_dict(), path)
    print(f"Model saved to {path}")

def load_model(model, path):
    """
    Load model weights from a file.
    
    Args:
        model: PyTorch model
        path: Path to the saved model
        
    Returns:
        Loaded model
    """
    model.load_state_dict(torch.load(path))
    return model

def save_results(results, dataset_name):
    """
    Save evaluation results to a file.
    
    Args:
        results: Dictionary of results
        dataset_name: Name of the dataset
    """
    results_dir = 'results'
    os.makedirs(results_dir, exist_ok=True)
    
    results_path = os.path.join(results_dir, f'{dataset_name}_results.json')
    
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=4)
    
    print(f"Results saved to {results_path}")

def set_seed(seed):
    """
    Set random seed for reproducibility.
    
    Args:
        seed: Random seed
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
